// import "./App.css";
import React from "react";
import Login from "./Login";

import Login2 from "./Login2";

import EventPractice from "./EventPractice";

function App() {
  return (
    <>
      {<Login />}
      {/* {<Login2 />} */}
    </>
  );
}

export default App;
