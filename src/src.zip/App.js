// import logo from "./logo.svg";
// import background from "./img/background.jpg";
import "./App.css";
import "./pd.css";
import logo from "./logo.png";
import help from "./help.png";
import { makeStyles } from "@material-ui/core/styles";

import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Checkbox from "@material-ui/core/Checkbox";
import Link from "@material-ui/core/Link";

const useStyles = makeStyles({
  root: {
    // fontFamily: "Noto Sans KR",
  },
  list: {
    fontSize: 10,
  },
  ka: {
    width: 270,
    height: 45,
    fontSize: 16,
    fontWeight: "bold",
    backgroundColor: "#FEE34A",
    border: 1,
    borderRadius: 10,
    marginTop: 10,
    boxShadow: "none",
  },
  btn: {
    width: 270,
    height: 45,
    fontSize: 16,
    color: "#FFFFFF",
    fontWeight: "bold",
    backgroundColor: "#3474E4",
    border: 1,
    borderRadius: 10,
  },
  txt: {
    width: 270,
    height: 45,
    marginTop: 20,
    fontWeight: "bold",
    borderRadius: 10,
  },
  right: {
    fontSize: 12,
  },
});
function App() {
  const classes = useStyles();
  return (
    <div className="app">
      <header className="header">
        <div className="logotitle">
          <img src={logo} className="logo" />
        </div>
      </header>
      <div className="main">
        <div className="login">
          <div className="login-left">
            <div className="content">
              <div className="logintext">로그인</div>
              <TextField
                className={classes.txt}
                // style={{ height: 10 }}
                id="filled-basic"
                label="회사 ID"
                variant="filled"
              />
              <TextField
                className={classes.txt}
                // style={{ height: 10 }}
                id="filled-basic"
                label="사용자 ID"
                variant="filled"
              />
              <TextField
                className={classes.txt}
                // style={{ height: 10 }}
                id="filled-basic"
                label="비밀번호"
                variant="filled"
              />

              {/* <div className={classes.list}> */}
              <div className="input">
                <Checkbox color="primary"></Checkbox>
                {/* <input type="checkbox"></input> */}
                <span className="span">아이디저장</span>
                <Link color="inherit" href="/">
                  <span>아이디/비밀번호를 잊으셨나요?</span>
                </Link>
              </div>

              <Button
                className="input"
                variant="contained"
                className={classes.btn}
              >
                로그인
              </Button>
              {/* <div className=""> */}
              <Button variant="contained" className={classes.ka}>
                카카오 계정으로 로그인
              </Button>
              {/* </div> */}
              <div className="input2">
                <Link color="inherit" href="/">
                  {/* <span className={classes.spanb}> */}
                  '카카오 계정으로 로그인' 등록 방법
                  {/* </span> */}
                </Link>
              </div>

              {/* <input type="checkbox"></input>아이디저장 */}
            </div>
          </div>

          <div className="login-right">
            <div className="righttxt1">
              본 인사정보 시스템은 (주)월급날에서 제공합니다. <br />
              비정상적 접근 시 법적 조치를 받을 수 있습니다.
            </div>
            <div className="righttxt2">
              {" "}
              <img src={help} className="help" /> 익스플로러 사용 시 도움말
            </div>
          </div>
        </div>
      </div>
      <footer className="footer">
        <p>
          <br />
          220-81-99881 | (주)월급날 | 대표자:임호천 | 02-785-0642 | 서울시
          영등포구 국회대로 68길 18 (여의도동, 금영빌딩)10층 <br />ⓒ 2016 payday
          co., Ltd. All Rights Reserved.
        </p>
      </footer>
    </div>

    // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // </div>
  );
}

export default App;
